<?php

return [
    'host' => 'localhost',
    'user' => 'root',
    'pass' => '',
    'db' =>'chat',
    'charset' => 'utf8'
];