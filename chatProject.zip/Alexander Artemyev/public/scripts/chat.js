async function chat() {
    var conn = new WebSocket('ws://localhost:8080');

    conn.onopen = function(event) {
        getMessages();
    };

    conn.onerror = function(event) {
        alert('Не удалось соединиться с сервером');
        logout();
    };

    conn.onmessage = function(event) {
        var data = JSON.parse(event.data),
            messageWrap = createMessageWrap('senderMessage', data.message, data.userName);

        chatWindow.appendChild(messageWrap);
        messageWrap.scrollIntoView(false);
    };

    var chatWindow = document.querySelector('div.chatWindow'),
        sendButton = document.querySelector('#sendMessage'),
        msgField   = document.forms['chatForm'].elements['message'],
        userData   = await serverInteraction('POST', 'auth/getUserData'),
        endMessagesFlag = false,
        messageOffset   = 0;

    var getMessages = async function() {
            if(!endMessagesFlag){
                var data = await serverInteraction('POST', 'chat/getMessages', JSON.stringify({offset: messageOffset})),
                    userDataParsed = JSON.parse(userData),
                    messages = JSON.parse(data);

                if(messages.length !== 0) {
                    messages.forEach(
                        function(message) {
                            var messageWrap;

                            if(message.user_name === userDataParsed.userName) {
                                messageWrap = createMessageWrap('myMessage', message.message_content, 'Вы');
                            } else {
                                messageWrap = createMessageWrap('senderMessage', message.message_content, message.user_name);
                            }

                            chatWindow.insertBefore(messageWrap, chatWindow.children[0]);
                        }
                    );

                    chatWindow.children[chatWindow.childElementCount - 10 * messageOffset - 1].scrollIntoView();
                    messageOffset++;
                } else {
                    endMessagesFlag = true;
                }
            }
        };

    var createMessageWrap = function (messageTypeClass, messageInnerText, userInnerText) {
        var messageWrap  = document.createElement('div'),
            userNameWrap = document.createElement('div');

        messageWrap.classList.add('messageWrap', messageTypeClass);
        userNameWrap.classList.add('messageUserName');

        messageWrap.innerText  = messageInnerText;
        userNameWrap.innerText = userInnerText;

        messageWrap.appendChild(userNameWrap);

        return messageWrap;
    };

    sendButton.onclick = async function() {
        var userDataParsed = JSON.parse(userData);
        if(msgField.value) {
            var data        = await serverInteraction('POST', 'chat/addMessage', JSON.stringify({message: msgField.value})),
                response    = JSON.parse(data),
                messageWrap = createMessageWrap('myMessage', msgField.value, 'Вы');

            if(response.result) {
                conn.send(JSON.stringify({userName: userDataParsed.userName, message: response.message}));
                chatWindow.appendChild(messageWrap);
                messageWrap.scrollIntoView(false);
                msgField.value = '';
            } else {
                alert('Ошибка: Ваше сообщение не может быть отправлено');
                conn.close();
                logout();
            }
        } else {
            alert('Введите сообщение');
        }
    };

    msgField.onkeydown = function(event) {
        if(event.keyCode === 13) {
            event.preventDefault();
            sendButton.click();
        }
    };

    chatWindow.onscroll = function() {
        if (this.scrollTop === 0) {
            if(!endMessagesFlag) {
                getMessages();
            }
        }
    };
}

chat();