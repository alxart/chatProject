function serverInteraction(method, path, data) {
    return new Promise(function(resolve) {
        var xhr = new XMLHttpRequest();
        xhr.open(method, path, true);
        xhr.setRequestHeader('Content-type', 'application/json; charset=utf-8');

        xhr.onreadystatechange = function() {
            if(this.readyState === XMLHttpRequest.DONE) {
                resolve(this.response)
            }
        };

        xhr.send(data);
    });
}

function register() {
    var userName    = document.forms['loginForm'].elements['userName'].value,
        userPass    = document.forms['loginForm'].elements['userPass'].value,
        responseDiv = document.querySelector('.loginResponse');
    responseDiv.classList.remove('error', 'success');
    serverInteraction('POST', 'auth/register', JSON.stringify({userName: userName, userPass: userPass}))
        .then(
            function(data) {
                var response = JSON.parse(data);
                responseDiv.innerText = response.message;
                if(response.result) {
                    responseDiv.classList.add('success');
                    document.forms['loginForm'].elements['userName'].value = '';
                    document.forms['loginForm'].elements['userPass'].value = '';
                } else {
                    responseDiv.classList.add('error');
                }
            }
        )
}

function login() {
    var userName    = document.forms['loginForm'].elements['userName'].value,
        userPass    = document.forms['loginForm'].elements['userPass'].value,
        responseDiv = document.querySelector('.loginResponse');
    responseDiv.classList.remove('error', 'success');
    serverInteraction('POST', 'auth/login', JSON.stringify({userName: userName, userPass: userPass}))
        .then(
            function(data) {
                var response = JSON.parse(data);
                responseDiv.innerText = response.message;
                if(response.result) {
                    responseDiv.classList.add('success');
                    setTimeout(location.replace('/chat?apiKey=' + response.apiKey), 3000);
                } else {
                    responseDiv.classList.add('error');
                }
            }
        );
}

function logout() {
    serverInteraction('POST', 'auth/logout')
        .then(
            function(data) {
                var response = JSON.parse(data);
                if(response.result) {
                    setTimeout(location.reload(true), 5000);
                }
            }
        );
}