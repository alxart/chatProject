document.querySelector('#regInChat').addEventListener('click', register);
document.querySelector('#joinToChat').addEventListener('click', login);