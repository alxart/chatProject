<?php

namespace App;

class Auth
{
    public static function authCheck() : bool {
        if(!empty($_SESSION['userName']) && !empty($_SESSION['userId'])) {
            return true;
        } else {
            return false;
        }
    }

    public static function authCompare(string $userName, string $userId) : bool {
        if(($_SESSION['userName'] === $userName) && ($_SESSION['userId'] === $userId)) {
            return true;
        } else {
            return false;
        }
    }

    public static function authStart($userName, $userId) {
        $_SESSION['userName'] = $userName;
        $_SESSION['userId']   = $userId;
    }

    public static function authEnd() {
        unset($_SESSION['userName']);
        unset($_SESSION['userId']);
    }

    public static function getAuthData() : array {
        return ['sessionUserName' => $_SESSION['userName'], 'sessionUserId' => $_SESSION['userId']];
    }
}