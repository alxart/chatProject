<?php

define('DOCUMENT_DIR', $_SERVER['DOCUMENT_ROOT']);
define('TEMPLATES_DIR', DOCUMENT_DIR . '/../templates/');