<?php

namespace App\Api;

use App\Modules\APIKey;
use App\Auth;
use App\DbInteraction;
use App\Twig;

class MyAPI extends API
{
    protected $origin;
    protected $db;
    private $rules = [
        ':userName'    => 'string',
        ':userPass'    => 'string',
        ':userId'      => 'numeric',
        ':msgContent'  => 'string',
        ':msgDate'     => 'string',
        ':offset'      => 'integer'
    ];

    public function __construct($request, $origin) {
        session_start();
        $this->origin = $origin;
        $this->db     = DbInteraction::getInstance();
        parent::__construct($request);
    }

    private function keyCheck(APIKey $APIKey) {
        if (!array_key_exists('apiKey', $this->request)) {
            throw new \Exception('No API Key provided');
        } else if (!$APIKey->verifyKey($this->request['apiKey'], $this->origin)) {
            throw new \Exception('Invalid API Key');
        }
    }

    protected function chat() {
        if($this->verb === '') {
            if($auth = Auth::authCheck()) {
                try {
                    $apiKey = new APIKey();
                    $this->keyCheck($apiKey);
                    return Twig::render('chat.tmpl', ['auth' => $auth, 'username' => Auth::getAuthData()['sessionUserName']]);
                } catch(\Exception $e) {
                    return Twig::render('403.tmpl', []);
                }
            } else {
                return Twig::render('chat.tmpl', ['auth' => $auth]);
            }
        }

        if($this->verb === 'addMessage') {
            if(Auth::authCheck()) {
                $errorCode = $this->db->executeQuery("INSERT INTO messages (user_id, message_content, message_date) VALUES (:userId, :msgContent, :msgDate)",
                                                     true,
                                                     [':userId' => Auth::getAuthData()['sessionUserId'], ':msgContent' => $this->request['message'], ':msgDate' => date('Y-m-d H:i:s')],
                                                     $this->rules);

                if($errorCode === 0) {
                    return ['message' => $this->request['message'], 'result' => true];
                } else {
                    return ['result' => false];
                }
            }
        }

        if($this->verb === 'getMessages') {
            if(Auth::authCheck()) {
                $messages = $this->db->getBindQueryResult("SELECT message_content, user_name FROM messages m INNER JOIN users u ON m.user_id = u.user_id ORDER BY message_date DESC LIMIT :offset, 10",
                                                          [':offset' => $this->request['offset'] * 10],
                                                          $this->rules);

                return $messages;
            }
        }

        throw new \Exception("Unexpected Verb");
    }

    protected function auth() {
        if($this->verb === 'register') {
            if(!empty($this->request['userName'])) {
                if(!empty($this->request['userPass'])) {
                    $errorCode = $this->db->executeQuery("INSERT INTO users (user_name, user_pass) VALUES (:userName, :userPass)",
                                                         true,
                                                         [':userName' => $this->request['userName'], ':userPass' => md5($this->request['userPass'])],
                                                         $this->rules);
                    if($errorCode === 0) {
                        return ['message' => 'Successful registration', 'result' => true];
                    } elseif($errorCode === 1062) {
                        return ['message' => 'User already exist', 'result' => false];
                    } else {
                        return ['message' => 'Error. Please, try later', 'result' => false];
                    }
                } else {
                    return ['message' => 'Input password', 'result' => false];
                }
            } else {
                return ['message' => 'Input username', 'result' => false];
            }
        }

        if($this->verb === 'logout') {
            if(Auth::authCheck()) {
                Auth::authEnd();
            }
            return ['result' => true];
        }

        if($this->verb === 'login') {
            if(Auth::authCheck()) {
                return ['message' => 'User already signed`', 'result' => true];
            }
            if(!empty($this->request['userName'])) {
                if(!empty($this->request['userPass'])) {
                    $userData = $this->db->getQuerySingleResult("SELECT * FROM users WHERE user_name = :userName",
                                                                [':userName' => $this->request['userName']],
                                                                $this->rules);
                    if($userData['user_pass'] === md5($this->request['userPass'])) {
                        Auth::authStart($this->request['userName'], $userData['user_id']);
                        $apiKey = new APIKey();
                        return ['message' => 'Successful login', 'apiKey' => $apiKey->getKey(), 'result' => true];
                    } else {
                        return ['message' => 'Wrong password', 'result' => false];
                    }
                } else {
                    return ['message' => 'Input password', 'result' => false];
                }
            } else {
                return ['message' => 'Input username', 'result' => false];
            }
        }

        if($this->verb === 'getUserData') {
            if(Auth::authCheck()) {
                return ['userName' => Auth::getAuthData()['sessionUserName'], 'userId' => Auth::getAuthData()['sessionUserId']];
            }
        }

        throw new \Exception("Unexpected Verb");
    }
}