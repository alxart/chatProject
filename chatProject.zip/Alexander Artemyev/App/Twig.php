<?php

namespace App;


class Twig
{
    public static function render(string $tmpl, array $params = []) {
        $loader = new \Twig_Loader_Filesystem(TEMPLATES_DIR);
        $twig   = new \Twig_Environment($loader);
        if(!empty($tmpl)) {
            $template = $twig->loadTemplate($tmpl);
            return $template->render($params);
        } else {
            $template = $twig->loadTemplate('404.tmpl');
            return $template->render([]);
        }
    }
}