<?php

namespace App;

class Validator
{
    public static function validate($values, $rules) {
        if(!empty(array_diff_key($values, $rules))) {
            throw new \InvalidArgumentException('Not valid');
        } else {
            foreach ($rules as $key => $rule) {
                if(!isset($values[$key])) {
                    continue;
            }
                if(function_exists('is_' . $rule)) {
                    if(!call_user_func('is_' . $rule, $values[$key])) {
                        throw new \InvalidArgumentException('Not valid');
                    }
                } else {
                    throw new \InvalidArgumentException('Not valid');
                }
            }
        }
    }
}