<?php

namespace App;

class DbInteraction
{
    use Singleton;

    private static $pdo;
    const CONFIG = [
        'host' => 'localhost',
        'user' => 'root',
        'pass' => '',
        'db' =>'chat',
        'charset' => 'utf8'
    ];

    private function __construct() {
        $dsn = 'mysql:host=' . self::CONFIG['host'] . ';dbname=' . self::CONFIG['db'] . ';charset=' . self::CONFIG['charset'];
        $options = [
            //\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
            \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
        ];
        self::$pdo = new \PDO($dsn, self::CONFIG['user'], self::CONFIG['pass'], $options);
    }

    private function getPDO() {
        return self::$pdo;
    }

    public function getQueryResult(string $query, array $params, array $rules) {
        try {
            Validator::validate($params, $rules);
            $pdo = $this->getPDO();
            $queryResult = $pdo->prepare($query);
            $queryResult->execute($params);
            return $queryResult->fetchAll();
        } catch (\Exception $e) {
            return null;
        }
    }

    public function getQuerySingleResult(string $query, array $params, array $rules) {
        try {
            Validator::validate($params, $rules);
            $pdo = $this->getPDO();
            $queryResult = $pdo->prepare($query);
            $queryResult->execute($params);
            $singleResult = $queryResult->fetchAll();
            return $singleResult[0];
        } catch (\Exception $e) {
            return null;
        }
    }

    public function executeQuery(string $query, bool $isErrNeeded, array $params, array $rules) {
        try {
            Validator::validate($params, $rules);
            $pdo         = $this->getPDO();
            $queryResult = $pdo->prepare($query);
            $queryResult->execute($params);

            if($isErrNeeded) {
                $errorInfo = $queryResult->errorInfo();
                if($errorInfo[1] === null) {
                    $errorInfo[1] = 0;
                }
                return $errorInfo[1];
            }
            return $queryResult->fetchAll();
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    public function getBindQueryResult(string $query, array $params, array $rules) {
        try {
            Validator::validate($params, $rules);
            $pdo = $this->getPDO();
            $queryResult = $pdo->prepare($query);

            foreach($params as $key => $param) {
                if(is_integer($param)) {
                    $queryResult->bindValue($key, $param, \PDO::PARAM_INT);
                } else {
                    $queryResult->bindValue($key, $param, \PDO::PARAM_STR);
                }
            }

            $queryResult->execute();
            return $queryResult->fetchAll();
        } catch(\Exception $e) {
            return null;
        }
    }
}