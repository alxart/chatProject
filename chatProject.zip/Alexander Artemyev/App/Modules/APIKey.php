<?php

namespace App\Modules;


class APIKey
{
    private $key;

    public function __construct() {
        $this->key = md5(md5('1234567890'));
    }

    public function verifyKey($key, $origin) {
        if($origin !== $_SERVER['SERVER_NAME']) {
            return false;
        }
        return $this->key === $key;
    }

    public function getKey() {
        return $this->key;
    }
}